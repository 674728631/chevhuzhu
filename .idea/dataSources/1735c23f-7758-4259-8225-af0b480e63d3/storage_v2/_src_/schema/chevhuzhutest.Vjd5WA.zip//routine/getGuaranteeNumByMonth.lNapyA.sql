CREATE FUNCTION getGuaranteeNumByMonth()
  RETURNS VARCHAR(255)
  BEGIN
	#Routine body goes here...
	SET @rs = '';
	SET @begin_date = '2018-04-01 00:00:00';
	SET @count = 0;
	
	SELECT TIMESTAMPDIFF(MONTH, @begin_date ,CURRENT_DATE) INTO @count;
	
	WHILE @count >= 0 DO
	
		SET @temp = '';
		SET @timeBegin ='';
		SET @timeSignout ='';
		
		select date_add(curdate() - day(curdate()) +1,interval -@count+1 month ) INTO @timeBegin;
		
    select date_add(curdate() - day(curdate()) +1,interval -@count month ) INTO @timeSignout;
		
	  SELECT
			COUNT( * ) AS guaranteeNum-- 为保障中
		FROM
			cbh_car car 
		WHERE
	
			timeBegin < @timeBegin
			AND ((`status` =30 and timeSignout > @timeSignout) or `status`=20)
			
		INTO @temp;
	
		/*
		select DATE_FORMAT(@timeBegin,'%y%m') into @timeBegin;
		set @tempRs = CONCAT(@timeBegin-1,'/',@temp);
		if @count>0 then
			set @rs = CONCAT(@rs,@tempRs,'-'); 
		else
			set @rs = CONCAT(@rs,@tempRs);
		end if;
		*/
		if @count>0 then
			set @rs = CONCAT(@rs,@temp,',');
		else
			set @rs = CONCAT(@rs,@temp);
		end if;
		
		set @count = @count -1;
	END WHILE;
		
	RETURN @rs;
END;

