CREATE FUNCTION getEventNumByMonth()
  RETURNS VARCHAR(255)
  BEGIN
	#Routine body goes here...
	
	SET @rs = '';
	SET @begin_date = '2018-04-01 00:00:00';
	SET @count = 0;
	
	SELECT TIMESTAMPDIFF(MONTH, @begin_date ,CURRENT_DATE) INTO @count;
	SET  @count = @count - 1;
	
	WHILE @count >= -1 DO
	
		SET @num = '';
		SET @month = '';
		SET @outMonth = '';
		# 上个月第一天
		select DATE_FORMAT(date_add(curdate() - day(curdate()) +1,interval -@count month ),'%Y年%m月')  INTO @month;
		select DATE_FORMAT(date_add(curdate() - day(curdate()) +1,interval -@count-1 month ),'%Y年%m月')  INTO @outMonth;
		
		SELECT
				count( * ) eventNum
-- 				,
-- 				DATE_FORMAT( @timeSignout, '%Y年%m月' ) month
		FROM
				cbh_event
		WHERE
				statusEvent > 2
				AND isInvalid = 1
				AND DATE_FORMAT( createAt, '%Y年%m月' ) < @month
-- 		GROUP BY
-- 				month
-- 		ORDER BY
-- 				month
-- 		
		INTO @num;
				
		if @count>-1 then
			set @rs = CONCAT(@rs,@outMonth,'-',@num,',');
		else
			set @rs = CONCAT(@rs,@outMonth,'-',@num);
		end if;
			
		
			
		
		
		set @count = @count -1;
	END WHILE;	
	
	RETURN @rs;
END;

