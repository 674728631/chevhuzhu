CREATE FUNCTION NewProc()
  RETURNS INT
  BEGIN
	#Routine body goes here...
	
		DECLARE a  int DEFAULT 1;
		set @b = '';
		
		SELECT
-- 						c.portrait AS img,
-- 						c.customerPN AS mobileNumber,
-- 						cc.nameCarOwner AS name,
-- 						cc.licensePlateNumber,-- 川A0004K
						c.id as customerId
		-- 				,count(*)
		-- 				, IFNULL((rechar.amt),0)
						
				FROM
						cbh_user_customer c
				LEFT JOIN middle_customer_maintenanceshop cm ON c.openId = cm.openId
				LEFT JOIN cbh_car cc ON cc.customerId = c.id
				LEFT JOIN middle_business_maintenanceshop AS mbm ON mbm.maintenanceshopId = cm.maintenanceshopId
				LEFT JOIN cbh_user_business AS cub ON mbm.businessId = cub.id
		-- 		left join cbh_record_recharge as rechar on rechar.customerId = c.id and rechar.`status` = 1  and rechar.type<3 and rechar.eventType<3
				WHERE
						cc.status IN (13,20) 
		-- 				and licensePlateNumber='川A0004K'
			GROUP BY cc.licensePlateNumber into @b;
	RETURN a;
END;

