CREATE FUNCTION asdas()
  RETURNS VARCHAR(255)
  BEGIN
	#Routine body goes here...

	RETURN '';
END;

