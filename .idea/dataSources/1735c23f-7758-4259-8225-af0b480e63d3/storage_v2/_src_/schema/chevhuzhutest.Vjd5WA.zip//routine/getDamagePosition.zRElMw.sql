CREATE FUNCTION getDamagePosition()
  RETURNS VARCHAR(255)
  BEGIN
	#Routine body goes here...

set @a = '';
set @b = '';
set @c = '';
set @d = '';
set @e = '';
set @f= '';
set @g= '';
select count(*) '引擎盖' from cbh_event_assert a,cbh_event b where  a.eventNo=b.eventNo and b.statusEvent>31 and b.isInvalid = 1 and a.damagePosition like '%引擎盖%' INTO @a;
select count(*) '翼子板' from cbh_event_assert a,cbh_event b where  a.eventNo=b.eventNo and b.statusEvent>31 and b.isInvalid = 1 and a.damagePosition like '%翼子板%' into @b;
select count(*)  '保险杠' from cbh_event_assert a,cbh_event b where  a.eventNo=b.eventNo and b.statusEvent>31 and b.isInvalid = 1 and a.damagePosition like '%保险杠%' into @c;
select count(*)  '轮胎' from cbh_event_assert a,cbh_event b where  a.eventNo=b.eventNo and b.statusEvent>31 and b.isInvalid = 1 and a.damagePosition like '%轮胎%' into @d;
select count(*)  '车门' from cbh_event_assert a,cbh_event b where  a.eventNo=b.eventNo and b.statusEvent>31 and b.isInvalid = 1 and a.damagePosition like '%门%' into @e;
select count(*)  '顶棚' from cbh_event_assert a,cbh_event b where  a.eventNo=b.eventNo and b.statusEvent>31 and b.isInvalid = 1 and a.damagePosition like '%顶%' into @f;
select count(*)  'ABC柱' from cbh_event_assert a,cbh_event b where  a.eventNo=b.eventNo and b.statusEvent>31 and b.isInvalid = 1 and a.damagePosition like '%柱%' into @g;
select count(*)  '后盖' from cbh_event_assert a,cbh_event b where  a.eventNo=b.eventNo and b.statusEvent>31 and b.isInvalid = 1 and a.damagePosition like '%后备箱盖%' into @h;
	
	set @rs = CONCAT('引擎盖','-','翼子板','-','保险杠','-','轮胎','-','车门','-','车顶','-','ABC柱','-','后备箱',',',@a,'-',@b,'-',@c,'-',@d,'-',@e,'-',@f,'-',@g,'-',@h);
	
	RETURN @rs;
END;

