CREATE PROCEDURE baozhangzhong(IN current DATETIME)
  BEGIN
	#Routine body goes here...
	
	SET @rs = '';
	SET @begin_date = '2018-04-01 00:00:00';
	SET @end_time = ' 23:59:59';

	SET @count = 0;
	
	SELECT TIMESTAMPDIFF(MONTH, @begin_date ,CURRENT_DATE) INTO @count;
	
	WHILE @count> 0 DO
	
		SET @temp = '';
		SET @timeBegin ='';
		SET @timeSignout ='';
		
		select date_add(curdate() - day(curdate()) +1,interval -@count+1 month ) INTO @timeBegin;
		
		select LAST_DAY(@timeBegin) INTO @timeSignout;
		set @timeSignout = CONCAT(@timeSignout,@end_time);
		
		select date_add(curdate() - day(curdate()) +1,interval -@count month ) INTO @timeSignout;
		
	  SELECT
			COUNT( * ) AS guaranteeNum-- 为保障中
		FROM
			cbh_car car 
		WHERE
	
			timeBegin < @timeBegin
			AND ((`status` =30 and timeSignout > @timeSignout) or `status`=20)
			
		INTO @temp;
	
		set @count = @count -1;
		select DATE_FORMAT(@timeBegin,'%y%m') into @timeBegin;
		set @tempRs = CONCAT(@timeBegin,'/',@temp);
		set @rs = CONCAT(@rs,@tempRs,'---'); 
			
	END WHILE;
	select @rs;
END;

